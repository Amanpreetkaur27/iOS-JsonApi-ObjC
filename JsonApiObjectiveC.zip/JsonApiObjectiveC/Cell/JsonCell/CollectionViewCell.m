//
//  CollectionViewCell.m
//  JsonApiObjectiveC
//
//  Created by Android LDT on 09/03/22.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

@end
