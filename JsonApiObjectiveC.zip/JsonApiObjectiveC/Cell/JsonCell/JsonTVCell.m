//
//  JsonTVCell.m
//  JsonApiObjectiveC
//
//  Created by Android LDT on 07/03/22.
//

#import "JsonTVCell.h"

@implementation JsonTVCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
