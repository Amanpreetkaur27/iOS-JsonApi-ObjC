//
//  SceneDelegate.h
//  JsonApiObjectiveC
//
//  Created by Android LDT on 07/03/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

