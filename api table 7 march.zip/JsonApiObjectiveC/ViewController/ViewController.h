//
//  ViewController.h
//  JsonApiObjectiveC
//
//  Created by Android LDT on 07/03/22.
//
//https://reqres.in/api/users

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource , UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;

-(void)requestdata;

@end

