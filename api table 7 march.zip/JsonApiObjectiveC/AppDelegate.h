//
//  AppDelegate.h
//  JsonApiObjectiveC
//
//  Created by Android LDT on 07/03/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

